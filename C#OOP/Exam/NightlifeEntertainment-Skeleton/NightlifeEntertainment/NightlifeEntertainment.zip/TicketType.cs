﻿namespace NightlifeEntertainment
{
    using System;

    public enum TicketType
    {
        Regular,
        Student,
        VIP
    }
}
